import 'package:flutter/material.dart';

class LoginSuccessDialog extends StatelessWidget {
  const LoginSuccessDialog({super.key});

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 3), () {
      // Navigate to homepage after delay
      Navigator.of(context).pop(); // Close dialog
      // Navigator.pushReplacementNamed(context, '/home'); // Optional navigation
    });

    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.5),
      body: Center(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 24),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Profile success icon
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  color: Color(0xFFECEEFF),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.verified_user, size: 48, color: Color(0xFF6D6CE3)),
              ),
              const SizedBox(height: 20),

              // Title
              const Text(
                "Log in Successful!",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 10),

              // Subtitle
              const Text(
                "Please wait...\nYou will be directed to the homepage.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 24),

              // Loading Indicator
              const CircularProgressIndicator(color: Color(0xFF6D6CE3)),
            ],
          ),
        ),
      ),
    );
  }
}
