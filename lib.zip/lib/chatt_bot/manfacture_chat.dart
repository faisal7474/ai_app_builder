import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:iconsax/iconsax.dart';

class ManufacturingChatAssistantScreen extends StatefulWidget {
  const ManufacturingChatAssistantScreen({Key? key}) : super(key: key);

  @override
  State<ManufacturingChatAssistantScreen> createState() =>
      _ManufacturingChatAssistantScreenState();
}

class _ManufacturingChatAssistantScreenState
    extends State<ManufacturingChatAssistantScreen> {
  final TextEditingController _messageController = TextEditingController();
  final String userId = FirebaseAuth.instance.currentUser?.uid ?? "guest_user";
  final String geminiApiKey = "AIzaSyBJt_GRFf2LEtmhSSzIjygzuAYPF-jcQgc"; // Your key

  Future<void> sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    await FirebaseFirestore.instance
        .collection('chats')
        .doc(userId)
        .collection('messages')
        .add({
      'sender': 'User',
      'message': text,
      'timestamp': Timestamp.now(),
      'isUser': true,
    });

    _messageController.clear();
    final response = await getGeminiResponse(text);

    if (response != null) {
      await FirebaseFirestore.instance
          .collection('chats')
          .doc(userId)
          .collection('messages')
          .add({
        'sender': 'AI',
        'message': response,
        'timestamp': Timestamp.now(),
        'isUser': false,
      });
    }
  }

  Future<String?> getGeminiResponse(String userMessage) async {
    final Uri url = Uri.parse(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=$geminiApiKey"
    );

    try {
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "contents": [
            {
              "role": "user",
              "parts": [
                {"text": userMessage}
              ]
            }
          ]
        }),
      );

      final data = jsonDecode(res.body);

      if (res.statusCode == 200) {
        return data["candidates"]?[0]["content"]?["parts"]?[0]["text"]
            ?? "No response received";
      } else {
        print("Gemini API Error: ${data['error']}");
        return "⚠️ Gemini Error: ${data['error']['message']}";
      }
    } catch (e) {
      print("API exception: $e");
      return "❌ Failed to connect to Gemini API.";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manufacturing AI Chat", style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  .doc(userId)
                  .collection('messages')
                  .orderBy('timestamp', descending: false)
                  .snapshots(),
              builder: (c, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final msgs = snap.data!.docs;
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: msgs.length,
                  itemBuilder: (context, i) {
                    final data = msgs[i].data() as Map<String, dynamic>;
                    final isUser = data['isUser'] ?? false;
                    return Align(
                      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        padding: const EdgeInsets.all(12),
                        constraints: const BoxConstraints(maxWidth: 280),
                        decoration: BoxDecoration(
                          color: isUser ? const Color(0xFF8F9DFD) : Colors.grey[300],
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Text(
                          data['message'] ?? '',
                          style: TextStyle(color: isUser ? Colors.white : Colors.black),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          const Divider(height: 1),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            color: Colors.white,
            child: Row(
              children: [
                const Icon(Iconsax.message, color: Color(0xFF8F9DFD)),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: "Send a message...",
                      border: InputBorder.none,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Color(0xFF8F9DFD)),
                  onPressed: sendMessage,
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

