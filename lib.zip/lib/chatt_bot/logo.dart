import 'package:flutter/material.dart';
import 'welcome_screen.dart'; // Ensure the path is correct

class FlutterLogoScreen extends StatefulWidget {
  const FlutterLogoScreen({super.key});

  @override
  State<FlutterLogoScreen> createState() => _FlutterLogoScreenState();
}

class _FlutterLogoScreenState extends State<FlutterLogoScreen> {
  @override
  void initState() {
    super.initState();
    // Delay for 3 seconds, then navigate
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const WelcomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(flex: 2),
              Image.asset(
                'assets/logo.png', // Make sure this path is correct
                width: 120,
                height: 120,
              ),
              const SizedBox(height: 20),
              const Text(
                'BizGen AI',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const Spacer(flex: 2),
              const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
