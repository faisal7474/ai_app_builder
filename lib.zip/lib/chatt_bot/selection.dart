import 'package:flutter/material.dart';

// 👇 Import your destination screens
import 'start_service.dart';
import 'merchant_start.dart';
import 'manufacture_start.dart';
//import 'merchandise_onboarding_1.dart';

class BusinessTypeSelectionScreen extends StatefulWidget {
  const BusinessTypeSelectionScreen({super.key});

  @override
  State<BusinessTypeSelectionScreen> createState() =>
      _BusinessTypeSelectionScreenState();
}

class _BusinessTypeSelectionScreenState
    extends State<BusinessTypeSelectionScreen> {
  String? selectedBusinessType;

  void _goToNextScreen() {
    if (selectedBusinessType == 'Service-Based Business') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const StartServiceScreen()),
      );
    } else if (selectedBusinessType == 'Merchandising Business') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const OnboardingScreen()),
      );
    } else if (selectedBusinessType == 'Manufacturing Business') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ManufacturingWelcomeScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select a business type")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Business Type'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Which business chatbot do you want to create?',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            RadioListTile<String>(
              title: const Text('Service-Based Business'),
              value: 'Service-Based Business',
              groupValue: selectedBusinessType,
              onChanged: (value) {
                setState(() {
                  selectedBusinessType = value;
                });
              },
            ),
            RadioListTile<String>(
              title: const Text('Merchandising Business'),
              value: 'Merchandising Business',
              groupValue: selectedBusinessType,
              onChanged: (value) {
                setState(() {
                  selectedBusinessType = value;
                });
              },
            ),
            RadioListTile<String>(
              title: const Text('Manufacturing Business'),
              value: 'Manufacturing Business',
              groupValue: selectedBusinessType,
              onChanged: (value) {
                setState(() {
                  selectedBusinessType = value;
                });
              },
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: selectedBusinessType == null ? null : _goToNextScreen,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: const Text('Next'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
