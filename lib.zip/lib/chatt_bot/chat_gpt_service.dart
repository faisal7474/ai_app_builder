import 'dart:convert';
import 'package:http/http.dart' as http;

class GeminiService {
  static const String apiKey = "AIzaSyBJt_GRFf2LEtmhSSzIjygzuAYPF-jcQgc"; // Replace with your key
  static const String apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=$apiKey";

  static Future<String> sendMessage(String userMessage) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "contents": [
          {
            "parts": [
              {"text": userMessage}
            ]
          }
        ]
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final content = data['candidates'][0]['content']['parts'][0]['text'];
      return content;
    } else {
      print("Gemini API Error: ${response.body}");
      return "Sorry, an error occurred: ${response.body}";
    }
  }
}
