import 'package:flutter/material.dart';
import 'manufacturing_bottom_nav.dart'; // update path as needed
import 'service_chat.dart'; // update this import as needed
import 'login.dart'; // if Home should go to login screen

class StartServiceScreen extends StatelessWidget {
  const StartServiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Service Assistant'),
        backgroundColor: Colors.blueAccent,
      ),
      backgroundColor: Colors.white,
      body: Center(
        child: ElevatedButton.icon(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MerchandiseAssistantScreen()),
            );
          },
          icon: const Icon(Icons.support_agent, size: 28),
          label: const Text(
            "Start Service Chat",
            style: TextStyle(fontSize: 18),
          ),
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            backgroundColor: Colors.blueAccent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
          ),
        ),
      ),
      bottomNavigationBar: ManufacturingBottomNavBar(
        currentIndex: 1, // AI Assistant
        onTap: (index) {
          if (index == 0) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const LoginScreen()),
            );
          }
        },
      ),
    );
  }
}
